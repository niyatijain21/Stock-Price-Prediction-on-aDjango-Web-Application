from django.shortcuts import render
from dateutil.relativedelta import relativedelta
import datetime

from joblib import load
model = load('./savedmodels/model.joblib')


def predictor(request):
    return render(request, 'index.html')

def forminfo(request):
    fname = request.GET['fname']
    stock_type = request.GET['stock_type']
    decision_date = request.GET['decision_date']
    m = int(request.GET['m'])
    
    decision_date = datetime.datetime.strptime(decision_date, '%Y-%m-%d')
    
    # Add m number of months to the decision_date
    later_date = decision_date + relativedelta(months=m)
    decision = "KEEP"
    
    dayofweek = decision_date.weekday()
        
    Company_AAPL = 0
    Company_MSFT = 0
    Company_GOOGL = 0
    Company_AMZN = 0
    Company_META = 0
    if stock_type == 'AAPL':
        Company_AAPL = 1
    elif stock_type == 'MSFT':
        Company_MSFT = 1
    elif stock_type == 'GOOGL':
        Company_GOOGL = 1
    elif stock_type == 'AMZN':
        Company_AMZN = 1
    elif stock_type == 'META':
        Company_META = 1
        
    y_pred = model.predict([[decision_date.year, decision_date.month, decision_date.day, dayofweek, Company_AAPL, Company_GOOGL, Company_AMZN, Company_MSFT, Company_META],])
    price = y_pred[0].round(3)
    
    prediction_data = []

    while decision_date <= later_date:
        dayofweek = decision_date.weekday()
        
        Company_AAPL = 0
        Company_MSFT = 0
        Company_GOOGL = 0
        Company_AMZN = 0
        Company_META = 0
        if stock_type == 'AAPL':
            Company_AAPL = 1
        elif stock_type == 'MSFT':
            Company_MSFT = 1
        elif stock_type == 'GOOGL':
            Company_GOOGL = 1
        elif stock_type == 'AMZN':
            Company_AMZN = 1
        elif stock_type == 'META':
            Company_META = 1
        
        y_pred = model.predict([[decision_date.year, decision_date.month, decision_date.day, dayofweek, Company_AAPL, Company_GOOGL, Company_AMZN, Company_MSFT, Company_META],])
        predicted_price = y_pred[0].round(3)

        prediction_data.append({'date': decision_date.strftime('%Y-%m-%d'), 'predicted_price': predicted_price})
        
        decision_date += datetime.timedelta(days=1)
        
        if decision_date == later_date:
            if predicted_price > price:
                decision = "BUY"
            else:
                decision = "SELL"
        
    return render(request, 'result.html', {'result': predicted_price, 'fname': fname, 'decision': decision, 'prediction_data': prediction_data})